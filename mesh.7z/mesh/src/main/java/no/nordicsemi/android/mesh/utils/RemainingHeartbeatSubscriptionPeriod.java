package no.nordicsemi.android.mesh.utils;

public abstract class RemainingHeartbeatSubscriptionPeriod {

}
